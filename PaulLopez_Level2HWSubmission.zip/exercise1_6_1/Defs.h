#define PRINT1(a) printf("%i",a)
#define PRINT2(a,b) printf("%i and %i", a, b)
#define MAX2(x, y) (x<y ? y : x)
#define MAX3(x,y,z) (MAX2(x, MAX2(y,z)))
